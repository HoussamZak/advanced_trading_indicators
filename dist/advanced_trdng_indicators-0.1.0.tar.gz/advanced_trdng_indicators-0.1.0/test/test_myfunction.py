from advanced_indicators import myfunctions

def test_chopp_index():
    # Amsterdam to Berlin
    assert myfunctions.chopp_idx_signals()